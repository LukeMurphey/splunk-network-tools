
# We are explicitly loading the base classes and the fields in order to maintain backwards
# compatibility with older modulat inputs that used the single file modular input
from modular_input_base_class import *
from fields import *

"""
Below is the version of this library. This copy was built on 'Sat, 11 Nov 2017 21:18:00 -0600'. The identifier is
'1510456680'
"""
__version__ = '1.0'

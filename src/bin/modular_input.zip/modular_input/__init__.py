
# We are explicitly loading the base classes and the fields in order to maintain backwards
# compatibility with older modulat inputs that used the single file modular input
from modular_input_base_class import *
from fields import *

"""
Below is the version of this library. This copy was built on 'Sat, 2 Dec 2017 20:14:56 -0600'. The identifier is
'1512267296'
"""
__version__ = '52'

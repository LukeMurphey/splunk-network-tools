
# We are explicitly loading the base classes and the fields in order to maintain backwards
# compatibility with older modulat inputs that used the single file modular input
from modular_input_base_class import *
from fields import *

"""
Below is the version of this library. This copy was built on 'Thu, 25 Jan 2018 13:03:39 -0600'. The identifier is
'1516907019'
"""
__version__ = '51'
